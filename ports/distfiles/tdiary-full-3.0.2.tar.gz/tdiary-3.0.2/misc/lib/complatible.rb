# move to tdiary/compatible.rb
