# -*- coding: utf-8 -*-
# calendar2.rb language recource for Japanese

@calendar2_days_format = ["日", "月", "火", "水", "木", "金", "土"]
@calendar2_navi_format = ["前", "%d年<br>%d月", "次"]

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
