# -*- coding: utf-8 -*-
# ja/daily_theme.rb
#
# Copyright (c) 2005 SHIBATA Hiroshi <h-sbt@nifty.com>
# Distributed under the GPL

@daily_theme_label = '日替わりテーマ'
@daily_theme_label_desc = '日替わりテーマで使用するテーマ名を、1行につき1つ入力してください。'

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
