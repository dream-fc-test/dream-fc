# -*- coding: utf-8 -*-
def label_xmlrpc_url; 'XML-RPC API 設置先URL'; end
def label_xmlrpc_blogid; 'Blog ID'; end
def label_xmlrpc_username; 'ユーザ名'; end
def label_xmlrpc_password; 'パスワード'; end
def label_xmlrpc_lastname; '名'; end
def label_xmlrpc_firstname; '姓'; end
def label_xmlrpc_userid; 'ユーザID'; end

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
