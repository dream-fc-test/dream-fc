# ping.rb Chinese resources
if /conf/ =~ @mode then
	@ping_label_conf = 'Update ping'
	@ping_label_list = 'List of ping servers'
	@ping_label_list_desc = 'Specify URLs of ping request.'
	@ping_label_timeout = 'Timeout(sec)'
end

@ping_label_send = 'Sending ping'

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
