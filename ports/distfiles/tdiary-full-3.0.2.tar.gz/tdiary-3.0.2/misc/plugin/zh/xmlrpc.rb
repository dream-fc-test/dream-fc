def label_xmlrpc_url; 'XML-RPC API URL'; end
def label_xmlrpc_blogid; 'Blog ID'; end
def label_xmlrpc_username; 'Username'; end
def label_xmlrpc_password; 'Password'; end
def label_xmlrpc_lastname; 'last name'; end
def label_xmlrpc_firstname; 'first name'; end
def label_xmlrpc_userid; 'User ID'; end

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
