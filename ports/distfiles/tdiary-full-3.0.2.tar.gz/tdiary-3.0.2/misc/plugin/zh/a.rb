def a_conf_label; "Edit the dictionary file for the anchor plugin(a.rb)"; end
def a_conf_explain; "<p>A row is an anchor. The format is: key URL name. name is omittable. If you omit name, the key used as name.</p><p>e.g.) tdiary http://www.tdiary.org/ tDiary Official Website</p>"; end


# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
