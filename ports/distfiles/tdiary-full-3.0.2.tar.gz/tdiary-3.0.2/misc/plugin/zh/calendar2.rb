# calendar2.rb language recource for English

@calendar2_days_format = %w(Su Mo Tu We Th Fr Sa)
@calendar2_navi_format = ["<-", "%d<br>%d", "->"]


# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
