def append_css_label
	'新增樣式表(CSS)'
end

def append_css_desc
	<<-HTML
	<h3>CSS 元素</h3>
	<p>您可以在下面新增自定的樣式表元素。 </p>
	HTML
end

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
