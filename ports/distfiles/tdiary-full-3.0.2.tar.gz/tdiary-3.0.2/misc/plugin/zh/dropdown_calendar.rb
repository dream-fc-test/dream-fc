# English resource of dropdown_calendar.rb
#
# calendar: replace calendar with dropdown style.
#   Parameter: none.
#

@dropdown_calendar_label = 'Past Diaries'

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
