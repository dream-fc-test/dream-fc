# en/bq.rb
#
def bq_cite_from( cite )
	"cite from #{cite}"
end

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
