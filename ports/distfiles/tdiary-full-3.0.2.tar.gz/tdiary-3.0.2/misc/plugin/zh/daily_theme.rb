# zh/daily_theme.rb
#
# Copyright (c) 2005 SHIBATA Hiroshi <h-sbt@nifty.com>
# Distributed under the GPL

@daily_theme_label = 'Daily Theme'
@daily_theme_label_desc = 'List of theme name.'

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
