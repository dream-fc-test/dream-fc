# referer-utf8.rb

#
# this plugin is obsolete.
#

# Local Variables:
# mode: ruby
# indent-tabs-mode: t
# tab-width: 3
# ruby-indent-level: 3
# End:
