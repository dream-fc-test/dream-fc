/* version.c -- version */

#include "npc.h"

GLOBAL char version[]  = "npc.cgi V0.83";
INTERN char revision[] = "@(#)$Revision: 1.23 $";
INTERN char date[]     = "$Date: 1997/12/11 14:13:26 $";
INTERN char author[]   = "$Author: nir $";
INTERN char state[]    = "$State: Rel $";

