<?php
/**

[Manifesto]
Name="XOOPS Cube Legacy 2.2"
Depends=Legacy_RenderSystem,legacy
Url="https://github.com/xoopscube/legacy/"
Version="2.2"

[Theme]
RenderSystem=Legacy_RenderSystem
Format="XOOPS2 Legacy Style"
Author=XOOPS Cube Project Team
ScreenShot="screenshot.png"
Description="Full header with search. Layout with 2 Columns, left or right, and bottom center blocks."
W3C=NG

Licence="BSD"

*/
?>